<?php
include("database/db.php"); 

$ID_Number = $_GET['id'];

$sql = "DELETE FROM students WHERE ID_Number = '$ID_Number'";
$result = $conn->query($sql);

if (!$result) {
    die("Invalid query: " . $conn->error);
}

header("Location:main.php");
exit;
?>