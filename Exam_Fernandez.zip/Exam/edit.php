<?php
include("database/db.php");

    $ID_Number = $_GET['id'];

    $sql = "SELECT * FROM students WHERE ID_Number = '$ID_Number'";
    $result = $conn->query($sql);   
    
    if (!$result) {
        die("Invalid query: " . $conn->error);
    }
    
    $row = $result->fetch_assoc();
    
    if ($_SERVER["REQUEST_METHOD"] == "POST") {
        $ID_Number = $_POST['ID_Number'];
        $Name = $_POST['Name'];
        $Email = $_POST['Email'];
        $Course = $_POST['Course'];

        $sql = "UPDATE students SET ID_Number = '$ID_Number', Name = '$Name', Email = '$Email', Course = '$Course' WHERE ID_Number = '$ID_Number'";
        $result = $conn->query($sql);
    
        if (!$result) {
            die("Invalid query: " . $conn->error);
        }
    
        header("Location: main.php");
        exit;
    }
    
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.7.2/css/all.min.css">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-YvpcrYf0tY3lHB60NNkmXc5s9fDVZLESaAA55NDzOxhy9GkcIdslK1eN7N6jIeHz" crossorigin="anonymous"></script>
    <title>CRUD EXAM</title>
</head>
<body>



<div class="container text">
  <div class="row align-items">

    <div class="col">
    </div>

    <div class="col">   
      <h2>
        Create Student Records
      </h2>
<div class="card" style="width: 50rem;">
  <div class="card-body">
        <div class="container align-items-center">
                        <form method="post">
                        <div class="row mb-3">
                            <label class="col-sm-2 col-form-label">ID Number</label>
                            <div class="col-sm-10">
                            <input type="text" class="form-control" id="ID_Number" name="ID_Number" value="<?php echo $row['ID_Number'];?>">
                            </div>
                        </div>

                        <div class="row mb-3">
                            <label class="col-sm-2 col-form-label">Name</label>
                            <div class="col-sm-10">
                            <input type="text" class="form-control" id="Name" name="Name" value="<?php echo $row['Name'];?>">
                            </div>
                        </div>

                        <div class="row mb-3">
                            <label class="col-sm-2 col-form-label">Email</label>
                            <div class="col-sm-10">
                            <input type="email" class="form-control" id="Email" name="Email" value="<?php echo $row['Email'];?>">
                            </div>
                        </div>

                        <div class="row mb-3">
                            <label class="col-sm-2 col-form-label">Course</label>
                            <div class="col-sm-10">
                            <input type="text" class="form-control" id="Course" name="Course" value="<?php echo $row['Course'];?>">
                            </div>
                        </div>
                        
                        <button type="submit" class="btn btn-outline-success">Update Record</button>
                        <a class="btn btn-outline-dark" href="exam/main.php" role="button">Cancel</a>
                        </form>
        </div>
    </div>
</div>
    </div>

    <div class="col"> 
    </div>
    
  </div>
</div>



</body>
</html>