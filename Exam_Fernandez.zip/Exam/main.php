<?php
include("database/db.php");

// Fetch student records from the database
$sql = "SELECT * FROM students";
$result = $conn->query($sql);

if (!$result) {
    die("Invalid query: " . $conn->error);
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.7.2/css/all.min.css">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
    <title>Student Records</title>
</head>
<body>

<div class="container mt-5 d-flex justify-content-center">
    <div class="card p-3 shadow-sm" style="width: 400px;">  <!-- Centered Card -->
        
        <h5 class="fw-bold">Student Records</h5>

        <div class="d-grid gap-2 my-2">
            <a href="create.php" class="btn btn-outline-dark btn-sm">
                Add Student <i class="fa-solid fa-plus"></i>
            </a>
        </div>

        

        <div>
            <?php while ($row = $result->fetch_assoc()) { ?>
                <div class="card shadow-sm mb-3">
                    <div class="card-body d-flex justify-content-between align-items-center p-2">
                        
                        <div>
                            <h6 class="fw-bold mb-1"><?= $row['Name']; ?></h6>
                            <p class="text-muted small mb-1"><?= $row['Email']; ?></p>
                            <p class="small mb-1"><?= $row['ID_Number']; ?></p>
                            <p class="small mb-0"><?= $row['Course']; ?></p>
                        </div>

                        <div class="dropdown">
                            <button class="btn btn-light btn-sm" type="button" data-bs-toggle="dropdown">
                                <i class="fa-solid fa-ellipsis-vertical"></i>
                            </button>
                            <ul class="dropdown-menu dropdown-menu-end">
                                <li><a class="dropdown-item" href="edit.php?id=<?= $row['ID_Number']; ?>"><i class="fa-solid fa-pen-to-square me-2"></i>Edit</a></li>
                                <li><a class="dropdown-item text-danger" href="delete.php?id=<?= $row['ID_Number']; ?>"><i class="fa-solid fa-trash me-2"></i>Delete</a></li>
                            </ul>
                        </div>

                    </div>
                </div>
            <?php } ?>
        </div>

    </div>
</div>

</body>
</html>
